package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.domain.InterviewerDetails;

public interface InterviewerDetailsRepositoryInterface {

	
	public boolean addInterviewerDetails(InterviewerDetails interviewerDetails);
	
	public List<InterviewerDetails> getInterviewerDetailst(int applicantId);
   
	public boolean updateInterviewerDetails(InterviewerDetails interviewerDetails);

}
